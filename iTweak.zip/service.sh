#!/system/bin/sh
MODDIR=${0%/*}

$MODDIR/itweak.sh > /dev/null
